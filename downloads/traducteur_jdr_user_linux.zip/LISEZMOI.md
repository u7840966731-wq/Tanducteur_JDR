# Traducteur JDR — version Linux

## Lancer l'application

    chmod +x TraducteurJDR      # une seule fois
    ./TraducteurJDR

Le dossier `langues/` doit rester à côté de l'exécutable : c'est là que
l'appli va chercher les langues disponibles (et où déposer les tiennes).

## Créer tes propres langues (avancé)

`creer_pack_langue.py` est fourni en script Python plutôt qu'en
exécutable compilé — presque toutes les distributions Linux ont déjà
Python 3 installé, ça évite d'alourdir le téléchargement pour rien.

Il faut juste le module `cryptography` :

    pip install cryptography --break-system-packages   # ou dans un venv

    python3 creer_pack_langue.py squelette ma_langue.json
    # ... remplis ma_langue.json ...
    python3 creer_pack_langue.py chiffrer ma_langue.json langues/ma_langue.titanlang
