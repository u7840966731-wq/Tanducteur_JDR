#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
creer_pack_langue.py
=====================

Outil en ligne de commande pour créer / chiffrer / déchiffrer les fichiers
de bibliothèque de langue (`.titanlang`) utilisés par le Traducteur Titan.

Utilisation
-----------

1) Créer un nouveau fichier `.titanlang` à partir d'un JSON en clair :

       python3 tools/creer_pack_langue.py chiffrer mon_pack.json langues/mon_pack.titanlang

2) Déchiffrer un `.titanlang` existant en JSON, pour le lire ou le modifier :

       python3 tools/creer_pack_langue.py dechiffrer langues/titan.titanlang mon_pack.json

3) Générer un squelette de JSON vide, à remplir, pour démarrer une
   nouvelle langue (mode "lettres" par défaut, ou "dictionnaire") :

       python3 tools/creer_pack_langue.py squelette ma_nouvelle_langue.json
       python3 tools/creer_pack_langue.py squelette --mode dictionnaire ma_nouvelle_langue.json

Le format JSON attendu est documenté dans `lang_pack.py` (classe
`LanguagePack`) — voir aussi `langues_sources/titan.json` fourni en
exemple complet.
"""

import argparse
import json
import os
import sys

# Permet d'importer lang_pack.py qui se trouve dans le dossier parent.
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from lang_pack import LanguagePack, encrypt_pack, decrypt_pack, LangPackError  # noqa: E402


SKELETON_LETTERS = {
    "name": "Nom de la langue",
    "code": "code_court",
    "version": "1.0",
    "author": "",
    "mode": "lettres",
    "letter_blocks": {
        "a": ["..."], "b": ["..."], "c": ["..."], "d": ["..."], "e": ["..."],
        "f": ["..."], "g": ["..."], "h": ["..."], "i": ["..."], "j": ["..."],
        "k": ["..."], "l": ["..."], "m": ["...", "..."], "n": ["..."],
        "o": ["..."], "p": ["..."], "q": ["..."], "r": ["..."], "s": ["..."],
        "t": ["..."], "u": ["..."], "v": ["..."], "w": ["..."], "x": ["..."],
        "y": ["..."], "z": ["..."],
    },
    "unit_words": {str(i): "..." for i in range(10)},
    "scale_ten": "...",
    "scale_ten_euphonic": "...",
    "scale_hundred": "...",
    "scale_thousand": "...",
    "scale_million": "...",
    "negative_prefix": "...",
    "operators": {"+": "...", "-": "...", "x": "...", "*": "...", "/": "..."},
    "articles_drop": ["le", "la", "les"],
    "articles_to_de": ["du", "des", "de"],
    "de_word": "de",
    "pronouns": ["je", "tu", "il", "elle", "on", "nous", "vous", "ils", "elles"],
}

SKELETON_DICTIONARY = {
    "name": "Nom de la langue",
    "code": "code_court",
    "version": "1.0",
    "author": "",
    "mode": "dictionnaire",
    "dictionary": {
        "bonjour": "...",
        "chat": "...",
        "maison": "...",
        "manger": "...",
        "_note": "Clés en minuscules sans accents. Complète au fur et à "
                  "mesure : les mots absents restent affichés entre "
                  "crochets, ex. [motinconnu], ce qui les rend faciles à "
                  "repérer. Supprime cette clé '_note' avant utilisation.",
    },
    "unit_words": {str(i): "..." for i in range(10)},
    "scale_ten": "...",
    "scale_ten_euphonic": "...",
    "scale_hundred": "...",
    "scale_thousand": "...",
    "scale_million": "...",
    "negative_prefix": "...",
    "operators": {"+": "...", "-": "...", "x": "...", "*": "...", "/": "..."},
    "articles_drop": ["le", "la", "les"],
    "articles_to_de": ["du", "des", "de"],
    "de_word": "de",
    "pronouns": ["je", "tu", "il", "elle", "on", "nous", "vous", "ils", "elles"],
}


def cmd_chiffrer(args):
    with open(args.entree, "r", encoding="utf-8") as f:
        data = json.load(f)
    pack = LanguagePack.from_dict(data)
    os.makedirs(os.path.dirname(os.path.abspath(args.sortie)) or ".", exist_ok=True)
    with open(args.sortie, "wb") as f:
        f.write(encrypt_pack(pack))
    print(f"OK : « {pack.name} » chiffré dans {args.sortie}")


def cmd_dechiffrer(args):
    with open(args.entree, "rb") as f:
        token = f.read()
    try:
        pack = decrypt_pack(token)
    except LangPackError as exc:
        print(f"Erreur : {exc}", file=sys.stderr)
        sys.exit(1)
    with open(args.sortie, "w", encoding="utf-8") as f:
        json.dump(pack.to_dict(), f, ensure_ascii=False, indent=2)
    print(f"OK : déchiffré vers {args.sortie}")


def cmd_squelette(args):
    skeleton = SKELETON_DICTIONARY if args.mode == "dictionnaire" else SKELETON_LETTERS
    with open(args.sortie, "w", encoding="utf-8") as f:
        json.dump(skeleton, f, ensure_ascii=False, indent=2)
    print(f"OK : squelette ({args.mode}) écrit dans {args.sortie}. Remplis-le puis "
          f"chiffre-le avec la commande 'chiffrer'.")


def main():
    parser = argparse.ArgumentParser(description="Gestion des fichiers de bibliothèque de langue (.titanlang)")
    sub = parser.add_subparsers(dest="commande", required=True)

    p1 = sub.add_parser("chiffrer", help="Chiffre un JSON en .titanlang")
    p1.add_argument("entree", help="Fichier JSON en clair")
    p1.add_argument("sortie", help="Fichier .titanlang à créer")
    p1.set_defaults(func=cmd_chiffrer)

    p2 = sub.add_parser("dechiffrer", help="Déchiffre un .titanlang en JSON")
    p2.add_argument("entree", help="Fichier .titanlang")
    p2.add_argument("sortie", help="Fichier JSON à créer")
    p2.set_defaults(func=cmd_dechiffrer)

    p3 = sub.add_parser("squelette", help="Génère un squelette de JSON vide")
    p3.add_argument("sortie", help="Fichier JSON à créer")
    p3.add_argument("--mode", choices=["lettres", "dictionnaire"], default="lettres",
                     help="Type de squelette : substitution lettre par lettre (défaut) "
                          "ou dictionnaire mot à mot")
    p3.set_defaults(func=cmd_squelette)

    args = parser.parse_args()
    args.func(args)


if __name__ == "__main__":
    main()
